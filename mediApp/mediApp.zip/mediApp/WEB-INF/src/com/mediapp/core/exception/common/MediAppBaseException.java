package com.mediapp.core.exception.common;

/**
 * @author A461353
 *
 */
public class MediAppBaseException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public MediAppBaseException(String message) {
		super(message);
	    }

}
