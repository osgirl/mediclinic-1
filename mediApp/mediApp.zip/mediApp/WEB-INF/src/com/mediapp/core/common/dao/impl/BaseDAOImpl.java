package com.mediapp.core.common.dao.impl;

/**
 * @author A461353
 *
 */
public class BaseDAOImpl {

}
