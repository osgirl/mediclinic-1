/**
 * 
 */
package com.mediapp.domain.common;

import java.io.Serializable;

/**
 * @author A461353
 *
 */
public class MediAppBaseDomain implements Serializable, Cloneable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
