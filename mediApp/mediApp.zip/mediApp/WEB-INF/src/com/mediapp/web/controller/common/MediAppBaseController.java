/**
 * 
 */
package com.mediapp.web.controller.common;

import org.springframework.web.servlet.mvc.SimpleFormController;

/**
 * @author A461353
 * App level base controller to do common actions
 *
 */
public class MediAppBaseController extends SimpleFormController {

}
