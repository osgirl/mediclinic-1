package org.apache.jsp.WEB_002dINF.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import com.mediapp.domain.common.Person;

public final class logOut_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(3);
    _jspx_dependants.add("/WEB-INF/jsp/include.jsp");
    _jspx_dependants.add("/WEB-INF/jsp/footer.jsp");
    _jspx_dependants.add("/WEB-INF/tld/verticalMenuItemTag.tld");
  }

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("    \r\n");
      out.write("    \r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
      out.write("    <title>mediApp</title>    \r\n");
      out.write("\t<link rel=\"shortcut icon\" href=\"");
      out.print(request.getContextPath());
      out.write("/images/favicon.ico\" type=\"image/x-icon\" />\r\n");
      out.write("    <link href=\"");
      out.print(request.getContextPath());
      out.write("/css/mycss.css\" rel=\"stylesheet\" type=\"text/css\">\r\n");
      out.write("    <link href=\"");
      out.print(request.getContextPath());
      out.write("/css/autocomplete.css\" rel=\"stylesheet\" type=\"text/css\">\r\n");
      out.write("    <script type=\"text/javascript\" src=\"");
      out.print(request.getContextPath());
      out.write("/js/mediapp.js\"></script>    \r\n");
      out.write("\t<script type=\"text/javascript\" src=\"");
      out.print(request.getContextPath());
      out.write("/js/calendar_us.js\"></script>\r\n");
      out.write("\t<script type=\"text/javascript\" src=\"");
      out.print(request.getContextPath());
      out.write("/js/prototype.js\"></script>\r\n");
      out.write("\t<script type=\"text/javascript\" src=\"");
      out.print(request.getContextPath());
      out.write("/js/autocomplete.js\"></script>\r\n");
      out.write("\t<link rel=\"stylesheet\" href=\"");
      out.print(request.getContextPath());
      out.write("/css/calendar.css\">\r\n");
      out.write("\r\n");
      out.write("</head>\r\n");
      out.write("<body>\r\n");
      out.write("\t<div id=\"main\">\r\n");
      out.write("\t\t<div id=\"header\">\r\n");
      out.write("\t\t\t<div id=\"name\">\r\n");
      out.write("\t\t\t\t<h3> MediApp\r\n");
      out.write("\t\t\t\t</h3>\r\n");
      out.write("\t\t\t\t<h4> Easy way to get medical attention!\r\n");
      out.write("\t\t\t\t</h4>\r\n");
      out.write("\t\t\t</div>\r\n");
      out.write("\t\t\t<div id=\"controls\">\r\n");
      out.write("\t\t\t\t\t<form id=\"searchform\" action=\"");
      out.print(request.getContextPath());
      out.write("\" method=\"post\">\r\n");
      out.write("\t\t\t\t        ");
Person p = (Person)request.getSession().getAttribute("person");
				        	if (p != null) {
      out.write("\r\n");
      out.write("\t\t\t\t\t\t        <a href=\"logOut.htm\" >Logout</a>\r\n");
      out.write("\t\t\t\t        ");
} 
      out.write("\r\n");
      out.write("\t\t\t\t\t</form>\r\n");
      out.write("\t\t\t</div>\r\n");
      out.write("\t\t</div>\r\n");
      out.write("<div >\r\n");
      out.write("\t\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t\t\t<div align=\"right\">\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t\t\t");

									if (p != null){
										out.print("Welcome " + p.getUsername());
									}
								
      out.write("\r\n");
      out.write("\t\t\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t\t\t</div>\r\n");
      out.write("</div>\r\n");
      out.write("\t\t<div id=\"contentHeadLeft\">\r\n");
      out.write("\t\t\t<div id=\"contentHeadRight\">\r\n");
      out.write("\t\t\t\t\r\n");
      out.write("\t\t\t\t<div id=\"contentHeadCenter\">\r\n");
      out.write("\t\t\t\t\t\t\t<div id=\"menu\">\r\n");
      out.write("\t\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t</div>\t\t\t\t\r\n");
      out.write("\t\t\t\t</div>\r\n");
      out.write("\t\t\t</div>\t\t\r\n");
      out.write("\t\t</div>\r\n");
      out.write("<script type=\"text/javascript\">\r\n");
      out.write("//hide('Menu1');\r\n");
      out.write("//hide('Menu2');\r\n");
      out.write("\r\n");
      out.write("</script>");
      out.write("\r\n");
      out.write("<div id=\"contentBodyLeft\">\r\n");
      out.write("   <div id=\"contentBodyRight\">\r\n");
      out.write("    <div id=\"contentBodyCenter\">\r\n");
      out.write("     <div id=\"contentSingleEntry\" style=\"\">\r\n");
      out.write("      <div id=\"entries\">\r\n");
      out.write("       <div class=\"entryAlone\">\r\n");
      out.write("        <form name=\"logOut\" id=\"logOut\" method=\"post\" >\r\n");
      out.write("         <h4> You have successfully logged out</h4> <br>\r\n");
      out.write("         <a href = \"logon.htm\"> Login </a><br>\r\n");
      out.write("        </form>\r\n");
      out.write(" \r\n");
      out.write("       </div>\r\n");
      out.write("      </div>\r\n");
      out.write("      <div id=\"column\">\r\n");
      out.write("      </div>\r\n");
      out.write("     </div>\r\n");
      out.write("    </div>\r\n");
      out.write("   </div>\r\n");
      out.write("  </div>\r\n");
      out.write("  \r\n");
      out.write("\t\t<div id=\"contentFootLeft\">\r\n");
      out.write("\t\t\t<div id=\"contentFootRight\">\r\n");
      out.write("\t\t\t\t<div id=\"contentFootCenter\"/>\r\n");
      out.write("\t\t\t</div>\r\n");
      out.write("\t\t</div>\r\n");
      out.write("\t\t<div id=\"footer\">\r\n");
      out.write("\t\t\t<p id=\"copyright\">© MediApp</p>\r\n");
      out.write("\t\t\t<p id=\"info\">\r\n");
      out.write("\t\t\t\tBeta 1.0\r\n");
      out.write("\t\t\t</p>\r\n");
      out.write("\t\t</div>\r\n");
      out.write("\t</div>\r\n");
      out.write("\r\n");
      out.write("</body>\r\n");
      out.write("</html>\r\n");
      out.write(' ');
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
