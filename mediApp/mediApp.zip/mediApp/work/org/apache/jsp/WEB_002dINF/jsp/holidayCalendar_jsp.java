package org.apache.jsp.WEB_002dINF.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import com.mediapp.domain.common.Person;
import com.mediapp.domain.common.Person;

public final class holidayCalendar_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(3);
    _jspx_dependants.add("/WEB-INF/jsp/include.jsp");
    _jspx_dependants.add("/WEB-INF/jsp/footer.jsp");
    _jspx_dependants.add("/WEB-INF/tld/verticalMenuItemTag.tld");
  }

  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fmenu_005fverticalMenuItemTag_005fnobody;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fc_005fforEach_0026_005fvarStatus_005fitems;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fspring_005fbind_0026_005fpath;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005ffmt_005fformatDate_0026_005fvalue_005fpattern_005fnobody;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _005fjspx_005ftagPool_005fmenu_005fverticalMenuItemTag_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fc_005fforEach_0026_005fvarStatus_005fitems = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fspring_005fbind_0026_005fpath = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005ffmt_005fformatDate_0026_005fvalue_005fpattern_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
    _005fjspx_005ftagPool_005fmenu_005fverticalMenuItemTag_005fnobody.release();
    _005fjspx_005ftagPool_005fc_005fforEach_0026_005fvarStatus_005fitems.release();
    _005fjspx_005ftagPool_005fspring_005fbind_0026_005fpath.release();
    _005fjspx_005ftagPool_005ffmt_005fformatDate_0026_005fvalue_005fpattern_005fnobody.release();
    _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.release();
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("    \r\n");
      out.write("    \r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
 response.setHeader("Expires","Mon, 26 Jul 2020 05:00:00 GMT"); 
      out.write("\r\n");
      out.write("    <title>AppMent</title>\r\n");
      out.write("\t<link rel=\"shortcut icon\" href=\"");
      out.print(request.getContextPath());
      out.write("/images/shakehand1.ico\" type=\"image/x-icon\" />    \r\n");
      out.write("\t<link rel=\"stylesheet\" href=\"");
      out.print(request.getContextPath());
      out.write("/css/jquery-ui.css\" type=\"text/css\" />\r\n");
      out.write("\t<link href=\"");
      out.print(request.getContextPath());
      out.write("/css/mycss.css\" rel=\"stylesheet\" type=\"text/css\">\r\n");
      out.write("        <LINK REL=StyleSheet HREF=\"dimming.css\" TYPE=\"text/css\">\r\n");
      out.write("\t\t<SCRIPT LANGUAGE=\"JavaScript\" SRC=\"dimmingdiv.js\"></script>\r\n");
      out.write("\t\r\n");
      out.write("    <script type=\"text/javascript\"  src=\"");
      out.print(request.getContextPath());
      out.write("/js/jquery.min.js\"></script>\r\n");
      out.write("    <script type=\"text/javascript\"  src=\"");
      out.print(request.getContextPath());
      out.write("/js/jquery-ui.min.js\"></script>\r\n");
      out.write("\t<script type=\"text/javascript\" src=\"");
      out.print(request.getContextPath());
      out.write("/js/customalert.js\" ></script>\r\n");
      out.write("\t<script type=\"text/javascript\" src=\"");
      out.print(request.getContextPath());
      out.write("/js/prototype.js\"></script>\r\n");
      out.write("\t<script type=\"text/javascript\" src=\"");
      out.print(request.getContextPath());
      out.write("/js/autocomplete.js\"></script>\r\n");
      out.write("\t<script type=\"text/javascript\" src=\"");
      out.print(request.getContextPath());
      out.write("/js/calendar_us.js\"></script>\t\r\n");
      out.write("        \r\n");
      out.write("\t\r\n");
      out.write("\t\r\n");
      out.write("</head>\r\n");
      out.write("<body >\r\n");
      out.write("\t<div id=\"main\">\r\n");
      out.write("\t\t");
Person p = (Person)request.getSession().getAttribute("person"); 
      out.write("\r\n");
      out.write("\t\t\t");
if (p != null && p.getPersonTypeString() != null && p.getPersonTypeString().equals("Doctor")) {
      out.write(" \r\n");
      out.write("\t\r\n");
      out.write("\t\t<div id=\"header\" style=\"background: url(/images/medical.jpg) no-repeat;\">\r\n");
      out.write("\t\t\t<div id=\"name\">\r\n");
      out.write("\t\t\t\t<h3> MediApp\r\n");
      out.write("\t\t\t\t</h3>\r\n");
      out.write("\t\t\t\t<h4> Easy way to get medical attention!\r\n");
      out.write("\t\t\t\t</h4>\r\n");
      out.write("\t\r\n");
      out.write("\t\t\t</div>\r\n");
      out.write("\t\t\t<div id=\"controls\">\r\n");
      out.write("\t\t\t\t\t<form id=\"searchform\" action=\"");
      out.print(request.getContextPath());
      out.write("\" method=\"post\">\r\n");
      out.write("\t\t\t\t        ");

				        	if (p != null) {
      out.write("\r\n");
      out.write("\t\t\t\t\t\t        <a href=\"logOut.htm\" >Logout</a>\r\n");
      out.write("\t\t\t\t        ");
} 
      out.write("\r\n");
      out.write("\t\t\t\t\t</form>\r\n");
      out.write("\t\t\t</div>\r\n");
      out.write("\t\t</div>\r\n");
      out.write("\t\t");
}else{ 
      out.write("\r\n");
      out.write("\t\t<div id=\"header\" >\r\n");
      out.write("\t\t\t<div id=\"name\">\r\n");
      out.write("\t\t\t\t<h3> AppMent\r\n");
      out.write("\t\t\t\t</h3>\r\n");
      out.write("\t\t\t\t<h4> <font color=\"grey\">Easy way to get organized!</font>\r\n");
      out.write("\t\t\t\t</h4>\r\n");
      out.write("\t\r\n");
      out.write("\t\t\t</div>\r\n");
      out.write("\t\t\t<div id=\"controls\">\r\n");
      out.write("\t\t\t\t\t<form id=\"searchform\" action=\"");
      out.print(request.getContextPath());
      out.write("\" method=\"post\">\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t<a href=\"http://www.facebook.com/apps/application.php?id=152456314791817&v=info\" TARGET=\"_blank\">\r\n");
      out.write("\t\t\t\t\t<img src=\"/images/Facebook-Buttons-11-2.png\" title=\"Find us on Facebook\"  \r\n");
      out.write("\t\t\t\t\talt=\"Find us on Facebook\" width=\"21px\" border=\"0\"/></a><br/>\r\n");
      out.write("\t\t\t\t\t\r\n");
      out.write("\t\t\t\t        ");

				        	if (p != null) {
      out.write("\r\n");
      out.write("\t\t\t\t\t\t        <a href=\"logOut.htm\" >Logout</a>\r\n");
      out.write("\t\t\t\t        ");
} 
      out.write("\r\n");
      out.write("\t\t\t\t\t</form>\r\n");
      out.write("\t\t\t</div>\r\n");
      out.write("\t\t</div>\r\n");
      out.write("\t\t\r\n");
      out.write("\t\t");
} 
      out.write("\t\r\n");
      out.write("<div >\r\n");
      out.write("\t\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t\t\t<div align=\"right\">\t\t\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t \t\t\t\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t\t\t");

									if (p != null && p.getFirstName()==null){
										out.print("Welcome " + p.getUsername() );
									}else if(p != null && p.getFirstName()!=null){
										out.print("Welcome " + p.getFirstName() );
									}
								
      out.write("\r\n");
      out.write("\t\t\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t\t\t</div>\r\n");
      out.write("</div>\r\n");
      out.write("\t\t<div id=\"contentHeadLeft\">\r\n");
      out.write("\t\t\t<div id=\"contentHeadRight\">\r\n");
      out.write("\t\t\t\t\r\n");
      out.write("\t\t\t\t<div id=\"contentHeadCenter\">\r\n");
      out.write("\t\t\t\t\t\t\t\t<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"200\" height=\"30\" >      \r\n");
      out.write("\t\t\t\t\t\t\t\t\t<tr >     \r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t<td  >  \r\n");
      out.write("\t\t\t\t\t\t\t\t  \t\t\t<a href=\"/welcomePage.htm\" onClick=\"\" style=\"text-decoration:none\">\r\n");
      out.write("\t\t\t\t\t\t\t\t  \t\t\t<img src=\"/images/Home11.png\" ></img>\r\n");
      out.write("\t\t\t\t\t\t\t\t  \t\t\t</a>\r\n");
      out.write("\t\t\t\t\t\t\t\t  \t\t</td>\r\n");
      out.write("\t\t\t\t\t\t\t\t  \t\t<td align=\"center\">\r\n");
      out.write("\t\t\t\t\t\t\t\t  \t\t<img src=\"/images/phone11.png\"  onMouseover=\"showbox(event,'You can book appointment, postpone it or cancel it by sending SMS.</br>Following are the commands</br>1. To schedule an appointment with a fellow appmate at certain date and time</br>SCD &amp;lt;yourusername&amp;gt; &amp;lt;mm/dd/yyyy&amp;gt; &amp;lt;hh:mm:ss&amp;gt; &amp;lt;duration hh:mm:ss&amp;gt; &amp;lt;appmateusername&amp;gt; </br>2. To postpone any appointment that you have already schedule</br>RESCD &amp;lt;yourusername&amp;gt; &amp;lt;old mm/dd/yyyy&amp;gt; &amp;lt;old hh:mm:ss&amp;gt; &amp;lt;new mm/dd/yyyy&amp;gt; &amp;lt;new hh:mm:ss&amp;gt; &amp;lt;duration hh:mm:ss&amp;gt; </br>3. To cancel any appointment that you have already schedule</br>CANCEL &amp;lt;yourusername&amp;gt; &amp;lt;mm/dd/yyyy&amp;gt; &amp;lt;hh:mm:ss&amp;gt;</br>');\" onMouseout=\"hidebox();\"/>\r\n");
      out.write("\t\t\t\t\t\t\t\t  \t\t</td>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t\t\t\t</tr>\r\n");
      out.write("\t\t\t\t\t\t\t\t</table>\t\t\t\t\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t</div>\r\n");
      out.write("\t\t\t</div>\t\t\r\n");
      out.write("\t\t</div>\r\n");
      out.write(" \r\n");
      out.write("<div id=\"contentBodyLeft\">\r\n");
      out.write("   <div id=\"contentBodyRight\">\r\n");
      out.write("    <div id=\"contentBodyCenter\">\r\n");
      out.write("        \t<div class=\"stp\" style=\"margin-bottom:1.5em;\">\r\n");
      out.write("\t\t\t\t<div class=\"or\" style=\"margin:1em; padding:0;\" >\r\n");
      out.write("    \r\n");
      out.write("     <div id=\"contentSingleEntry\" style=\"\">\r\n");
      out.write("     \r\n");
      out.write("      <div id=\"entries\">\r\n");
      out.write("       <div class=\"entryAlone\">\r\n");
      out.write("        <form name=\"holidayCalendar\" id=\"holidayCalendar\" method=\"post\" >\r\n");
      out.write("\t\t\t\t\t\t\t\t\r\n");
      out.write("        \r\n");
      out.write("         <table width=900  border=\"1\" class=\"sample\"  > \r\n");
      out.write("          <tr>\r\n");
      out.write("           <td> \r\n");
      out.write("            <table width=200 align=\"left\"   class=\"sample\" style=\"border-width: 0px 0px 0px 0px;\">  \r\n");
      out.write("                   <tr>\r\n");
      out.write("        \t           \t<td>\r\n");
      out.write("            \t\t       \t");
      if (_jspx_meth_menu_005fverticalMenuItemTag_005f0(_jspx_page_context))
        return;
      out.write("\r\n");
      out.write("                   \t\t</td>\r\n");
      out.write("                   </tr>\r\n");
      out.write("            </table>\r\n");
      out.write("            <div id=\"History\"  style=\"display:block\" align=\"center\">\r\n");
      out.write("             <table  border=\"\"  class=\"sample\" id=\"tblHoliday\" width=680 cellpadding=\"200\" id=\"tblSample\"> \r\n");
      out.write("              <tr bgcolor=\"lightblue\" >\r\n");
      out.write("               Add Holidays\r\n");
      out.write("              </tr>\r\n");
      out.write("              <tr >\r\n");
      out.write("              \t<td width=\"5%\">\r\n");
      out.write("              \t</td>\r\n");
      out.write("               <td width=\"25%\">Holiday Date:\r\n");
      out.write("               </td>\r\n");
      out.write("               <td width=\"70%\" align=\"left\">Comments:\r\n");
      out.write("               </td>\r\n");
      out.write("              </tr>\r\n");
      out.write("              \r\n");
      out.write("             \r\n");
      out.write("\t\t       ");
      //  c:forEach
      org.apache.taglibs.standard.tag.rt.core.ForEachTag _jspx_th_c_005fforEach_005f0 = (org.apache.taglibs.standard.tag.rt.core.ForEachTag) _005fjspx_005ftagPool_005fc_005fforEach_0026_005fvarStatus_005fitems.get(org.apache.taglibs.standard.tag.rt.core.ForEachTag.class);
      _jspx_th_c_005fforEach_005f0.setPageContext(_jspx_page_context);
      _jspx_th_c_005fforEach_005f0.setParent(null);
      // /WEB-INF/jsp/holidayCalendar.jsp(40,9) name = items type = java.lang.Object reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
      _jspx_th_c_005fforEach_005f0.setItems((java.lang.Object) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${holidayCalendar.holidays}", java.lang.Object.class, (PageContext)_jspx_page_context, null, false));
      // /WEB-INF/jsp/holidayCalendar.jsp(40,9) name = varStatus type = java.lang.String reqTime = false required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
      _jspx_th_c_005fforEach_005f0.setVarStatus("holidays");
      int[] _jspx_push_body_count_c_005fforEach_005f0 = new int[] { 0 };
      try {
        int _jspx_eval_c_005fforEach_005f0 = _jspx_th_c_005fforEach_005f0.doStartTag();
        if (_jspx_eval_c_005fforEach_005f0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
          do {
            out.write("\r\n");
            out.write("\t\t\t        <tr>\r\n");
            out.write("\t\t\t        \t<td>\r\n");
            out.write("\t\t\t        \t\t<input type=\"checkbox\"  name=\"deleteChk\" id=\"deleteChk\" />\r\n");
            out.write("\t\t\t        \t</td>\r\n");
            out.write("\t                   <td >\r\n");
            out.write("\t                    ");
            //  spring:bind
            org.springframework.web.servlet.tags.BindTag _jspx_th_spring_005fbind_005f0 = (org.springframework.web.servlet.tags.BindTag) _005fjspx_005ftagPool_005fspring_005fbind_0026_005fpath.get(org.springframework.web.servlet.tags.BindTag.class);
            _jspx_th_spring_005fbind_005f0.setPageContext(_jspx_page_context);
            _jspx_th_spring_005fbind_005f0.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_c_005fforEach_005f0);
            // /WEB-INF/jsp/holidayCalendar.jsp(46,21) name = path type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
            _jspx_th_spring_005fbind_005f0.setPath((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("holidayCalendar.holidays[${holidays.index}].holidayDate", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
            int[] _jspx_push_body_count_spring_005fbind_005f0 = new int[] { 0 };
            try {
              int _jspx_eval_spring_005fbind_005f0 = _jspx_th_spring_005fbind_005f0.doStartTag();
              if (_jspx_eval_spring_005fbind_005f0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
                org.springframework.web.servlet.support.BindStatus status = null;
                status = (org.springframework.web.servlet.support.BindStatus) _jspx_page_context.findAttribute("status");
                do {
                  out.write("\r\n");
                  out.write("\t                     <input type=\"text\" name=\"");
                  out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${status.expression}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
                  out.write("\" id=\"");
                  out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${status.expression}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
                  out.write("\"  value=\"");
                  if (_jspx_meth_fmt_005fformatDate_005f0(_jspx_th_spring_005fbind_005f0, _jspx_page_context, _jspx_push_body_count_spring_005fbind_005f0))
                    return;
                  out.write("\"  style=\"WIDTH: 100px\" onblur=\"check_date(this)\"/>                \r\n");
                  out.write("\t                    ");
                  int evalDoAfterBody = _jspx_th_spring_005fbind_005f0.doAfterBody();
                  status = (org.springframework.web.servlet.support.BindStatus) _jspx_page_context.findAttribute("status");
                  if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
                    break;
                } while (true);
              }
              if (_jspx_th_spring_005fbind_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
                return;
              }
            } catch (Throwable _jspx_exception) {
              while (_jspx_push_body_count_spring_005fbind_005f0[0]-- > 0)
                out = _jspx_page_context.popBody();
              _jspx_th_spring_005fbind_005f0.doCatch(_jspx_exception);
            } finally {
              _jspx_th_spring_005fbind_005f0.doFinally();
              _005fjspx_005ftagPool_005fspring_005fbind_0026_005fpath.reuse(_jspx_th_spring_005fbind_005f0);
            }
            out.write("\r\n");
            out.write("\t                      <script language=\"JavaScript\">\r\n");
            out.write("\t                       new tcal ({\r\n");
            out.write("\t                        // form name\r\n");
            out.write("\t                        'formname': 'holidayCalendar',\r\n");
            out.write("\t                        // input name\r\n");
            out.write("\t                        'controlname': '");
            if (_jspx_meth_c_005fout_005f0(_jspx_th_c_005fforEach_005f0, _jspx_page_context, _jspx_push_body_count_c_005fforEach_005f0))
              return;
            out.write("'\r\n");
            out.write("\t                        });\r\n");
            out.write("\t                      </script>\r\n");
            out.write("\t                   </td>                \r\n");
            out.write("\t                   <td >\r\n");
            out.write("\t                    ");
            //  spring:bind
            org.springframework.web.servlet.tags.BindTag _jspx_th_spring_005fbind_005f1 = (org.springframework.web.servlet.tags.BindTag) _005fjspx_005ftagPool_005fspring_005fbind_0026_005fpath.get(org.springframework.web.servlet.tags.BindTag.class);
            _jspx_th_spring_005fbind_005f1.setPageContext(_jspx_page_context);
            _jspx_th_spring_005fbind_005f1.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_c_005fforEach_005f0);
            // /WEB-INF/jsp/holidayCalendar.jsp(59,21) name = path type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
            _jspx_th_spring_005fbind_005f1.setPath((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("holidayCalendar.holidays[${holidays.index}].comments", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
            int[] _jspx_push_body_count_spring_005fbind_005f1 = new int[] { 0 };
            try {
              int _jspx_eval_spring_005fbind_005f1 = _jspx_th_spring_005fbind_005f1.doStartTag();
              if (_jspx_eval_spring_005fbind_005f1 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
                org.springframework.web.servlet.support.BindStatus status = null;
                status = (org.springframework.web.servlet.support.BindStatus) _jspx_page_context.findAttribute("status");
                do {
                  out.write("\r\n");
                  out.write("\t                     <input type=\"text\" name=\"");
                  out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${status.expression}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
                  out.write("\" id=\"");
                  out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${status.expression}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
                  out.write("\"  value=\"");
                  out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${holidayCalendar.holidays[holidays.index].comments}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
                  out.write("\" style=\"WIDTH: 400px\"/>\r\n");
                  out.write("\t                                     \r\n");
                  out.write("\t                    ");
                  int evalDoAfterBody = _jspx_th_spring_005fbind_005f1.doAfterBody();
                  status = (org.springframework.web.servlet.support.BindStatus) _jspx_page_context.findAttribute("status");
                  if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
                    break;
                } while (true);
              }
              if (_jspx_th_spring_005fbind_005f1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
                return;
              }
            } catch (Throwable _jspx_exception) {
              while (_jspx_push_body_count_spring_005fbind_005f1[0]-- > 0)
                out = _jspx_page_context.popBody();
              _jspx_th_spring_005fbind_005f1.doCatch(_jspx_exception);
            } finally {
              _jspx_th_spring_005fbind_005f1.doFinally();
              _005fjspx_005ftagPool_005fspring_005fbind_0026_005fpath.reuse(_jspx_th_spring_005fbind_005f1);
            }
            out.write("\r\n");
            out.write("\t                   </td>\r\n");
            out.write("\t\t         \t</tr>\r\n");
            out.write("\t\t       ");
            int evalDoAfterBody = _jspx_th_c_005fforEach_005f0.doAfterBody();
            if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
              break;
          } while (true);
        }
        if (_jspx_th_c_005fforEach_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
          return;
        }
      } catch (Throwable _jspx_exception) {
        while (_jspx_push_body_count_c_005fforEach_005f0[0]-- > 0)
          out = _jspx_page_context.popBody();
        _jspx_th_c_005fforEach_005f0.doCatch(_jspx_exception);
      } finally {
        _jspx_th_c_005fforEach_005f0.doFinally();
        _005fjspx_005ftagPool_005fc_005fforEach_0026_005fvarStatus_005fitems.reuse(_jspx_th_c_005fforEach_005f0);
      }
      out.write("\r\n");
      out.write("              \r\n");
      out.write("            \r\n");
      out.write("             </table>\r\n");
      out.write("            </div>\r\n");
      out.write("          </tr>\r\n");
      out.write("           <tr>\r\n");
      out.write("            <td align=\"center\" colspan=\"2\">\r\n");
      out.write("            \r\n");
      out.write("\t            <input type=\"hidden\" value=\"1\" id=\"counter\"/>\r\n");
      out.write("\t            <input type=\"hidden\" value=\"N\" id=\"AddOperation\" name=\"AddOperation\"/>\r\n");
      out.write("\t\t\t\t<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"400\" height=\"30\" >         \r\n");
      out.write("\t\t\t\t\t<tr >     \r\n");
      out.write("\t\t\t\t\t\t<td  style=\"background: url(/images/submitbutton_0.png) no-repeat;overflow: hidden;background-position: top center;height:100%;width:33%\"  align=\"center\">  \r\n");
      out.write("\t\t\t\t  \t\t\t<a href=\"javascript:void(0);\" onClick=\"javascript:addRowToCalendar();\" style=\"text-decoration:none\"> \r\n");
      out.write("\t\t\t\t  \t\t\t\t<font size=\"+1\" color=\"#FFFFFF\" >Add Row</font> \r\n");
      out.write("\t\t\t\t  \t\t\t</a>\r\n");
      out.write("\t\t\t\t  \t\t</td>\r\n");
      out.write("\t\t\t\t  \t\t<td  style=\"background: url(/images/submitbutton_0.png) no-repeat;overflow: hidden;background-position: top center;height:100%;width:33%\" align=\"center\">  \r\n");
      out.write("\t\t\t\t  \t\t\t<a href=\"javascript:void(0);\" onClick=\"javascript:deleteRow('tblHoliday',this.form);\" style=\"text-decoration:none\"> \r\n");
      out.write("\t\t\t\t  \t\t\t\t<font size=\"+1\" color=\"#FFFFFF\" >Delete</font>\r\n");
      out.write("\t\t\t\t  \t\t\t</a>\r\n");
      out.write("\t\t\t\t  \t\t</td>\r\n");
      out.write("\t\t\t\t  \t\t<td  style=\"background: url(/images/submitbutton_0.png) no-repeat;overflow: hidden;background-position: top center;height:100%;width:33%\" align=\"center\">  \r\n");
      out.write("\t\t\t\t  \t\t\t<a href=\"javascript:void(0);\" onClick=\"javascript:fn_updateHolidayCalendar();\" style=\"text-decoration:none\"> \r\n");
      out.write("\t\t\t\t  \t\t\t\t<font size=\"+1\" color=\"#FFFFFF\" >Save</font> \r\n");
      out.write("\t\t\t\t  \t\t\t</a>\r\n");
      out.write("\t\t\t\t  \t\t</td>\r\n");
      out.write("\t\t\t\t  \t\t\r\n");
      out.write("\t\t\t\t\t</tr>\r\n");
      out.write("\t\t\t\t</table> \t\t\t\t\t\t\t\t\t\t\r\n");
      out.write("            </td>\r\n");
      out.write("           </tr>\r\n");
      out.write("          \r\n");
      out.write("          </table>\r\n");
      out.write("          \r\n");
      out.write("        </form>\r\n");
      out.write(" \r\n");
      out.write("       </div>\r\n");
      out.write("      </div>\r\n");
      out.write("      <div id=\"column\">\r\n");
      out.write("      </div>\r\n");
      out.write("     </div>\r\n");
      out.write("               </div></div>\r\n");
      out.write("     \r\n");
      out.write("    </div>\r\n");
      out.write("   </div>\r\n");
      out.write("  </div>\r\n");
      out.write("  \r\n");
      out.write("\t\t<div id=\"contentFootLeft\">\r\n");
      out.write("\t\t\t<div id=\"contentFootRight\">\r\n");
      out.write("\t\t\t\t<div id=\"contentFootCenter\"/>\r\n");
      out.write("\t\t\t</div>\r\n");
      out.write("\t\t</div>\r\n");
      out.write("\t\t<div id=\"footer\">\r\n");
      out.write("\t\t\t<p id=\"copyright\"></p>\r\n");
      out.write("\t\t\t<p id=\"info\">\r\n");
      out.write("\t\t\t\tBeta 1.0\r\n");
      out.write("\t\t\t</p>\r\n");
      out.write("\t\t</div>\r\n");
      out.write("\t</div>\r\n");
      out.write("    <script type=\"text/javascript\" src=\"");
      out.print(request.getContextPath());
      out.write("/js/mediapp.js\"></script>\r\n");
      out.write("<!-- Attach events to Link -->\r\n");
      out.write("<div id=\"helpbox\"></div>\r\n");
      out.write("\r\n");
      out.write("</body>\r\n");
      out.write("</html>\r\n");
      out.write('\r');
      out.write('\n');
      out.write(' ');
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }

  private boolean _jspx_meth_menu_005fverticalMenuItemTag_005f0(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  menu:verticalMenuItemTag
    com.mediapp.web.taglibs.VerticalMenuTag _jspx_th_menu_005fverticalMenuItemTag_005f0 = (com.mediapp.web.taglibs.VerticalMenuTag) _005fjspx_005ftagPool_005fmenu_005fverticalMenuItemTag_005fnobody.get(com.mediapp.web.taglibs.VerticalMenuTag.class);
    _jspx_th_menu_005fverticalMenuItemTag_005f0.setPageContext(_jspx_page_context);
    _jspx_th_menu_005fverticalMenuItemTag_005f0.setParent(null);
    int _jspx_eval_menu_005fverticalMenuItemTag_005f0 = _jspx_th_menu_005fverticalMenuItemTag_005f0.doStartTag();
    if (_jspx_th_menu_005fverticalMenuItemTag_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fmenu_005fverticalMenuItemTag_005fnobody.reuse(_jspx_th_menu_005fverticalMenuItemTag_005f0);
      return true;
    }
    _005fjspx_005ftagPool_005fmenu_005fverticalMenuItemTag_005fnobody.reuse(_jspx_th_menu_005fverticalMenuItemTag_005f0);
    return false;
  }

  private boolean _jspx_meth_fmt_005fformatDate_005f0(javax.servlet.jsp.tagext.JspTag _jspx_th_spring_005fbind_005f0, PageContext _jspx_page_context, int[] _jspx_push_body_count_spring_005fbind_005f0)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  fmt:formatDate
    org.apache.taglibs.standard.tag.rt.fmt.FormatDateTag _jspx_th_fmt_005fformatDate_005f0 = (org.apache.taglibs.standard.tag.rt.fmt.FormatDateTag) _005fjspx_005ftagPool_005ffmt_005fformatDate_0026_005fvalue_005fpattern_005fnobody.get(org.apache.taglibs.standard.tag.rt.fmt.FormatDateTag.class);
    _jspx_th_fmt_005fformatDate_005f0.setPageContext(_jspx_page_context);
    _jspx_th_fmt_005fformatDate_005f0.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_spring_005fbind_005f0);
    // /WEB-INF/jsp/holidayCalendar.jsp(47,103) name = pattern type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_fmt_005fformatDate_005f0.setPattern("MM/dd/yyyy");
    // /WEB-INF/jsp/holidayCalendar.jsp(47,103) name = value type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_fmt_005fformatDate_005f0.setValue((java.util.Date) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${holidayCalendar.holidays[holidays.index].holidayDate}", java.util.Date.class, (PageContext)_jspx_page_context, null, false));
    int _jspx_eval_fmt_005fformatDate_005f0 = _jspx_th_fmt_005fformatDate_005f0.doStartTag();
    if (_jspx_th_fmt_005fformatDate_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005ffmt_005fformatDate_0026_005fvalue_005fpattern_005fnobody.reuse(_jspx_th_fmt_005fformatDate_005f0);
      return true;
    }
    _005fjspx_005ftagPool_005ffmt_005fformatDate_0026_005fvalue_005fpattern_005fnobody.reuse(_jspx_th_fmt_005fformatDate_005f0);
    return false;
  }

  private boolean _jspx_meth_c_005fout_005f0(javax.servlet.jsp.tagext.JspTag _jspx_th_c_005fforEach_005f0, PageContext _jspx_page_context, int[] _jspx_push_body_count_c_005fforEach_005f0)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  c:out
    org.apache.taglibs.standard.tag.rt.core.OutTag _jspx_th_c_005fout_005f0 = (org.apache.taglibs.standard.tag.rt.core.OutTag) _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.get(org.apache.taglibs.standard.tag.rt.core.OutTag.class);
    _jspx_th_c_005fout_005f0.setPageContext(_jspx_page_context);
    _jspx_th_c_005fout_005f0.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_c_005fforEach_005f0);
    // /WEB-INF/jsp/holidayCalendar.jsp(54,41) name = value type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_c_005fout_005f0.setValue((java.lang.Object) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("holidays[${holidays.index}].holidayDate", java.lang.Object.class, (PageContext)_jspx_page_context, null, false));
    int _jspx_eval_c_005fout_005f0 = _jspx_th_c_005fout_005f0.doStartTag();
    if (_jspx_th_c_005fout_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005fout_005f0);
      return true;
    }
    _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005fout_005f0);
    return false;
  }
}
