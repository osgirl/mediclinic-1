button text: Login to Account >>
primary color: ffffff
gradient color: e5e5e5
width (pixels): 170
height (pixels): 68
corner radius (pixels): 15
text height (points): 12
text color: 0000ff
background color: cadef4
font name: DejaVuSansCondensed-Oblique
rollover primary color: 66ffff
rollover gradient color: 6666ff
rollover text color: 000000
quality: 3
image location: none
image height (pixels): 12
image name: 
image foreground color determination: auto
image foreground color: 000000
image transparent color determination: auto
image transparent color: ffffff
url: http://www.glassybuttons.com/buttonmill/glassy.php?button_text=Login+to+Account+%3E%3E&color=ffffff&grcolor=e5e5e5&width=170&height=68&radius=15&theight=12&tcolor=0000ff&bkcolor=cadef4&fname=DejaVuSansCondensed-Oblique&rcolor=66ffff&rgrcolor=6666ff&rtcolor=000000&imglocate=none&imgheight=12&imgname=&imgfore=auto&imgforecolor=000000&imgtran=auto&imgtrancolor=ffffff&quality=3&fromhere=1
